import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from datetime import datetime


# BACKEND HOOKS 
@st.cache_data
def load_data():
    df = pd.read_csv(r"enhanced_data.csv")  
    return df


def score_with_xgb(df: pd.DataFrame) -> pd.DataFrame:
    
    # risk_score -> riskscorexgb
    if "risk_score" in df.columns and "riskscorexgb" not in df.columns:
        df["riskscorexgb"] = df["risk_score"]

    # is_anomaly -> isanomaly
    if "is_anomaly" in df.columns and "isanomaly" not in df.columns:
        df["isanomaly"] = df["is_anomaly"]

    # anomaly_type already exists; just ensure correct name
    if "anomaly_type" in df.columns and "anomalytype" not in df.columns:
        df["anomalytype"] = df["anomaly_type"]

    return df


def score_with_rl(df: pd.DataFrame) -> pd.DataFrame:
    # TODO: plug RL output if you want to show RL decisions
    # e.g., add rl_decision, rl_confidence
    # reuse XGBoost-like score
    return score_with_xgb(df)


st.set_page_config(
    page_title="Insider Threat Anomaly Dashboard",
    layout="wide",
    initial_sidebar_state="expanded",
)


# Global styles
st.markdown(
    """
    <style>
    .metric-small {
        font-size: 0.9rem;
        opacity: 0.8;
    }
    .risk-high {color: #d62728; font-weight: 600;}
    .risk-medium {color: #ff7f0e; font-weight: 600;}
    .risk-low {color: #2ca02c; font-weight: 600;}
    </style>
    """,
    unsafe_allow_html=True,
)


#SIDEBAR – model & filters
st.sidebar.title("Controls")

model_choice = st.sidebar.radio(
    "Detection model",
    ["XGBoost", "RL + Autoencoder"],
    index=0,
)

risk_threshold = st.sidebar.slider(
    "Risk threshold (for high‑risk flag)",
    min_value=0.5,
    max_value=0.999,
    value=0.9,
    step=0.01,
)

top_k = st.sidebar.slider(
    "Top‑K sessions to display",
    min_value=10,
    max_value=200,
    value=50,
    step=10,
)

st.sidebar.markdown("---")

st.sidebar.markdown("**Session filters**")
department_filter = st.sidebar.multiselect("Department", [])
app_filter = st.sidebar.multiselect("Application", [])
country_filter = st.sidebar.multiselect("Country", [])
only_anomalies = st.sidebar.checkbox("Show only anomalies", value=True)


# DATA + SCORING
df_raw = load_data()
df = df_raw.copy()

# Rename CSV cols
col_map = {
    "user_id": "userid",
    "department": "department",
    "privilege_level": "privilegelevel",
    "session_id": "sessionid",
    "timestamp": "timestamp",
    "login_time": "logintime",
    "logout_time": "logouttime",
    "session_minutes": "sessionminutes",
    "device_type": "devicetype",
    "location_country": "locationcountry",
    "ip_address": "ipaddress",
    "remote_ip": "remoteip",
    "remote_ip_type": "remoteiptype",
    "port_used": "portused",
    "files_accessed": "filesaccessed",
    "bytes_downloaded": "bytesdownloaded",
    "direction": "direction",
    "app_used": "appused",
    "file_sensitivity": "filesensitivity",
    "sensitive_command": "sensitivecommand",
    "failed_logins": "failedlogins",
    "mfa_used": "mfaused",
    "time_risk": "timerisk",
    "file_risk": "filerisk",
    "geo_risk": "georisk",
    "app_risk": "apprisk",
    "auth_risk": "authrisk",
    "risk_score": "riskscorexgb",
    "alert_priority": "alertpriority",
    "anomaly_score": "anomalyscore",
    "is_anomaly": "isanomaly",
    "anomaly_type": "anomalytype",
}
df.rename(columns=col_map, inplace=True)

# st.write("Columns in CSV (after rename):", list(df.columns))

if model_choice == "XGBoost":
    df = score_with_xgb(df)
    risk_col = "riskscorexgb"
    model_tag = "XGBoost"
else:
    df = score_with_rl(df)
    risk_col = "riskscorexgb"
    model_tag = "RL"

# Post‑processing high‑risk flag via quantile/threshold
if risk_col in df.columns:
    thresh = df[risk_col].quantile(risk_threshold)
    df["is_high_risk"] = (df[risk_col] >= thresh).astype(int)
else:
    df["is_high_risk"] = 0


# dynamic filters based on data - working on this
if not department_filter and "department" in df.columns:
    department_filter = sorted(df["department"].dropna().unique().tolist())
if not app_filter and "appused" in df.columns:
    app_filter = sorted(df["appused"].dropna().unique().tolist())
if not country_filter and "locationcountry" in df.columns:
    country_filter = sorted(df["locationcountry"].dropna().unique().tolist())

# Apply filters
mask = (
    df["department"].isin(department_filter)
    & df["appused"].isin(app_filter)
    & df["locationcountry"].isin(country_filter)
)

if only_anomalies and "isanomaly" in df.columns:
    mask &= df["isanomaly"] == 1

df_filtered = df[mask].copy()


# 2. HEADER + KPI STRIP
st.title("Team UNO - Anomaly Detection & Insider Threat Dashboard")

st.caption(
    f"Model: **{model_tag}** | Risk metric: **{risk_col}** | Sessions: {len(df_filtered)}"
)

col1, col2, col3, col4 = st.columns(4)

with col1:
    total_sessions = len(df)
    st.metric("Total sessions", f"{total_sessions:,}")

with col2:
    total_anomalies = int(df.get("isanomaly", pd.Series([0] * len(df))).sum())
    st.metric("Total anomalies", f"{total_anomalies:,}")

with col3:
    high_risk_sessions = int(df["is_high_risk"].sum())
    st.metric("High‑risk sessions", f"{high_risk_sessions:,}")

with col4:
    unique_users = df["userid"].nunique()
    st.metric("Unique users", f"{unique_users:,}")

st.markdown("---")

# 3. LAYOUT TABS
tab_alerts, tab_users, tab_timeline, tab_features = st.tabs(
    ["Alert Dashboard", "User Profiles", "Timeline", "Feature Insights"]
)

# 3.1 ALERT DASHBOARD
with tab_alerts:
    st.subheader("High‑Risk Sessions")

    if df_filtered.empty:
        st.info("No sessions match the current filters.")
    else:
        top_df = (
            df_filtered.sort_values(risk_col, ascending=False)
            .head(top_k)[
                [
                    "userid",
                    "department",
                    "privilegelevel",
                    "sessionid",
                    "logintime",
                    "logouttime",
                    "filesaccessed",
                    "bytesdownloaded",
                    "appused",
                    "anomalytype",
                    risk_col,
                ]
            ]
        )

        # Risk bucket column
        def risk_bucket(score):
            if score >= 0.95:
                return "High"
            elif score >= 0.85:
                return "Medium"
            return "Low"

        top_df["risk_level"] = top_df[risk_col].apply(risk_bucket)

        st.dataframe(
            top_df.style.format(
                {
                    risk_col: "{:.4f}",
                    "bytesdownloaded": "{:,}",
                    "filesaccessed": "{:,}",
                }
            ),
            use_container_width=True,
            height=450,
        )

        # Distribution chart as in notebook [file:1]
        st.markdown("### Risk score distribution")
        fig_hist = px.histogram(
            df_filtered,
            x=risk_col,
            nbins=50,
            color="isanomaly" if "isanomaly" in df_filtered.columns else None,
            color_discrete_map={0: "steelblue", 1: "crimson"},
            title="Distribution of model‑predicted risk scores",
        )
        st.plotly_chart(fig_hist, use_container_width=True)

# 3.2 USER PROFILES
with tab_users:
    st.subheader("User Risk Profiles")

    if risk_col in df.columns:
        user_risk = (
            df.groupby("userid")[risk_col]
            .max()
            .sort_values(ascending=False)
            .head(50)
            .reset_index()
        )
        st.markdown("#### Top risky users (max risk per user)")
        fig_users = px.bar(
            user_risk,
            x="userid",
            y=risk_col,
            title="Top users by maximum risk score",
        )
        fig_users.update_layout(xaxis_title="User ID", yaxis_title="Max risk")
        st.plotly_chart(fig_users, use_container_width=True)

    # User drill‑down
    st.markdown("#### User drill‑down")
    selected_user = st.selectbox(
        "Select user",
        sorted(df["userid"].unique()),
    )

    user_df = df[df["userid"] == selected_user].copy()
    if not user_df.empty:
        c1, c2, c3 = st.columns(3)
        with c1:
            st.markdown("**User ID**")
            st.write(selected_user)
            st.markdown(
                "<span class='metric-small'>Department</span>",
                unsafe_allow_html=True,
            )
            st.write(user_df["department"].iloc[0])
        with c2:
            st.markdown("**Privilege level**")
            st.write(user_df["privilegelevel"].iloc[0])
            st.markdown(
                "<span class='metric-small'>Distinct apps</span>",
                unsafe_allow_html=True,
            )
            st.write(user_df["appused"].nunique())
        with c3:
            st.markdown("**Sessions**")
            st.write(len(user_df))
            if risk_col in user_df.columns:
                st.markdown(
                    "<span class='metric-small'>Max risk</span>",
                    unsafe_allow_html=True,
                )
                st.write(f"{user_df[risk_col].max():.4f}")

        st.markdown("#### Sessions for selected user")
        st.dataframe(
            user_df[
                [
                    "sessionid",
                    "logintime",
                    "logouttime",
                    "sessionminutes",
                    "devicetype",
                    "locationcountry",
                    "appused",
                    "filesaccessed",
                    "bytesdownloaded",
                    "anomalytype",
                    risk_col,
                ]
            ].sort_values(risk_col, ascending=False),
            use_container_width=True,
            height=350,
        )

# 3.3 TIMELINE VIEW
with tab_timeline:
    st.subheader("Timeline of login sessions")

    if "logintime" not in df.columns:
        st.info("No timestamp/logintime column available.")
    else:
        df_t = df.copy()
        df_t["logintime_dt"] = pd.to_datetime(
            df_t["logintime"], errors="coerce"
        )

        min_dt = df_t["logintime_dt"].min()
        max_dt = df_t["logintime_dt"].max()
        if pd.notnull(min_dt) and pd.notnull(max_dt):
            start_dt, end_dt = st.date_input(
                "Date range",
                value=(min_dt.date(), max_dt.date()),
                min_value=min_dt.date(),
                max_value=max_dt.date(),
            )
            mask_dt = (
                (df_t["logintime_dt"].dt.date >= start_dt)
                & (df_t["logintime_dt"].dt.date <= end_dt)
            )
            df_t = df_t[mask_dt]

        entity_mode = st.radio(
            "Timeline mode",
            ["All users", "Single user"],
            horizontal=True,
        )

        if entity_mode == "Single user":
            u = st.selectbox("User", sorted(df_t["userid"].unique()))
            df_t = df_t[df_t["userid"] == u]

        if df_t.empty:
            st.info("No sessions in this date range / filter.")
        else:
            y_axis = "userid" if entity_mode == "All users" else "sessionid"

            fig_t = px.scatter(
                df_t,
                x="logintime_dt",
                y=y_axis,
                color=risk_col if risk_col in df_t.columns else None,
                hover_data=[
                    "userid",
                    "sessionid",
                    "appused",
                    "filesaccessed",
                    "bytesdownloaded",
                    "anomalytype",
                ],
                title="Session timeline",
            )
            fig_t.update_yaxes(type="category")
            st.plotly_chart(fig_t, use_container_width=True)


# 3.4 FEATURE & APP INSIGHTS
with tab_features:
    st.subheader("Feature & Application Insights")

    st.markdown("#### Risk drivers (high‑risk sessions)")

    if risk_col in df.columns:
        high_mask = df["is_high_risk"] == 1
        num_features = [
            "bytesdownloaded",
            "filesaccessed",
            "sessionminutes",
            "filerisk",
            "devicerisk",
            "georisk",
            "apprisk",
            "authrisk",
        ]
        num_features = [f for f in num_features if f in df.columns]

        if num_features:
            drivers = (
                df[high_mask][num_features].mean().sort_values(ascending=False).head(10)
            )
            drivers_df = drivers.reset_index()
            drivers_df.columns = ["feature", "avg_value"]
            fig_drv = px.bar(
                drivers_df,
                x="feature",
                y="avg_value",
                title="Top numerical features for high‑risk sessions",
            )
            st.plotly_chart(fig_drv, use_container_width=True)

    st.markdown("#### Application usage vs high‑risk (XGBoost appusage block)")

    if {"appused", "userid", risk_col}.issubset(df.columns):
        dfx = df.copy()
        dfx["is_high_risk"] = df["is_high_risk"]
        appusage = (
            dfx.groupby("appused")
            .agg(
                total_uses=("userid", "count"),
                high_risk_uses=("is_high_risk", "sum"),
            )
            .reset_index()
        )
        fig_app = px.scatter(
            appusage,
            x="total_uses",
            y="high_risk_uses",
            text="appused",
            title="Application usage vs high‑risk users",
        )
        fig_app.update_traces(textposition="top center")
        fig_app.update_layout(
            xaxis_title="Total app uses", yaxis_title="High‑risk uses"
        )
        st.plotly_chart(fig_app, use_container_width=True)

    st.markdown(
        "You can plug SHAP plots or ML explainer outputs here (as used in the notebook) "
        "to justify **why** a session is flagged."
    )
