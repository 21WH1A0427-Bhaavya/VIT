package com.javaprep.intermediate.app;
import java.util.Scanner;
class Student {
    int rollNo;
    String name;
    public Student(int rollNo, String name) {
        this.rollNo = rollNo;
        this.name = name;
    }
    public String toString() {
        return "Student: name = " + name + " rollNo = " + rollNo;
    } //Override
}
public class StringsArrays {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // StringBuffer s = new StringBuffer("Bhaavya");
        // s.append(" Ramita");
        // System.out.println(s);

        // int nums[] = {1, 2, 3, 4, 5};
        // int num[] = new int[3];
        // num[0] = 1;
        // num[1] = 2;
        // num[2] = 3;

        // for(int i=0; i<nums.length; i++) {
        //     System.out.print(nums[i] + " ");
        // }
        // System.out.println();
        // for(int i: num) {
        //     System.out.println(i);
        // }

        Student st = new Student(3, "Bhaavya");
        Student students[] = new Student[4]; //array of objects
        System.out.println(st); //by default calls the .toString() function which we override

        for(int i=0; i<students.length; i++) {
            int rollNo = sc.nextInt();
            String name = sc.next();
            students[i] = new Student(rollNo, name);
        }

        for(Student t: students) {
            System.out.println(t);
        }
    }
}
