package com.javaprep.intermediate.app;
import java.util.Scanner;
class Keyboard {
    private int keys; //keys = instance varaible
    private String color;

    //getters and setters
    public void setKeys(int keys) {  //keys = local variable
        this.keys = keys; 
    }
    public int getKeys() {
        return keys;
    }
    
    public void isPressed() {
        System.out.println("YES");
    }
    public void throwIt() {
        System.out.println("NO");
    }
}
class AdvKeyboard extends Keyboard {
    public void throwIt() {
        System.out.println("sent num");
    }
    public void throwIt(int spaces) { //method overloading = same name but parameters present
        System.out.println(spaces);
    }
}
public class Demo {
    public static void main(String args[]) {
        System.out.println("Hello World");
        int num = 10;
        show(num);

        AdvKeyboard obj = new AdvKeyboard();
        obj.isPressed();
        obj.throwIt(); //method overriding = prints "sent num" from AdvKeyword instead of NO
        obj.throwIt(50);
        obj.setKeys(10);
        System.out.println(obj.getKeys());
    }
    public static void show(int num) {
        System.out.println(num);
    }
}