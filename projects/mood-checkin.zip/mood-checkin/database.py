import sqlite3
from datetime import datetime

DB_NAME = "mental_health.db"

def get_connection():
    return sqlite3.connect(DB_NAME, check_same_thread=False)

def init_db():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS moods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mood TEXT,
            timestamp TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS chats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT,
            emotion TEXT,
            timestamp TEXT
        )
    """)

    conn.commit()
    conn.close()

def save_mood(mood):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO moods (mood, timestamp) VALUES (?, ?)",
        (mood, datetime.now().strftime("%Y-%m-%d %H:%M"))
    )
    conn.commit()
    conn.close()

def save_chat(message, emotion):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO chats (message, emotion, timestamp) VALUES (?, ?, ?)",
        (message, emotion, datetime.now().strftime("%Y-%m-%d %H:%M"))
    )
    conn.commit()
    conn.close()

def get_mood_history():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT mood, timestamp FROM moods ORDER BY timestamp DESC")
    rows = cur.fetchall()
    conn.close()
    return rows

def get_chat_history():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT emotion, timestamp FROM chats ORDER BY timestamp DESC")
    rows = cur.fetchall()
    conn.close()
    return rows
