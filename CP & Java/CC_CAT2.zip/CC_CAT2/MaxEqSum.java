import java.util.Scanner;
public class MaxEqSum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0; i<n; i++){
            arr[i] = sc.nextInt();
        }
        int total = 0;
        for(int i: arr) {
            total += i;
        }
        int left = 0;
        int mx = -1;
        for(int i=0; i<n; i++) {
            int right = total - left - arr[i];
            if(right == left) {
                mx = Math.max(mx, left);
            }
            left += arr[i];
        }
        System.out.println(mx);
    }
}