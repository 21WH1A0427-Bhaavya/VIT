import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;
public class Majority {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0; i<n; i++) {
            arr[i] = sc.nextInt();
        }
        HashMap<Integer, Integer> map = new HashMap<>();
        for(int i : arr) {
            map.put(i, map.getOrDefault(i, 0)+1);
        }
        boolean found = false;
        for(HashMap.Entry<Integer, Integer> entry : map.entrySet()) {
            if(entry.getValue() > n/2) {
                System.out.println(entry.getKey());
                found = true;
                break;
            }
        }
        if(!found) {
            System.out.println(-1);
        }
    }
}