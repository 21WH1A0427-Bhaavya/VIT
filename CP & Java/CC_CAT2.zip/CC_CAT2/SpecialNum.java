import java.util.Scanner;
public class SpecialNum {
    public static boolean isPrime(int num) {
        if(num < 2) {
            return false;
        }
        for(int i=2; i*i<num; i++) {
            if(num%i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int l = sc.nextInt();
        int r = sc.nextInt();
        int total = r-l+1;
        int special;
        int count = 0;
        for(int i=2; i*i<=r; i++) {
            if(isPrime(i)) {
                special = i*i;
                if(special >= l && special <= r) {
                    count += 1;
                }
            }
        }
        System.out.println(total - count);
    }
}