import java.util.Scanner;

public class BinaryPalindrome {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String s = Integer.toBinaryString(n);
        int i=0, j = s.length()-1;
        while(i<j) {
            if(s.charAt(i) != s.charAt(j)) {
                System.out.println("NO");
                break;
            }
            i += 1;
            j -= 1;
        }
        System.out.println("YES");
    }
}
