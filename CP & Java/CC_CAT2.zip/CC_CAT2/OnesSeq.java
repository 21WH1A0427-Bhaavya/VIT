import java.util.Scanner;
public class OnesSeq {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0; i<n; i++) {
            arr[i] = sc.nextInt();
        }
        int zero = 0;
        int left = 0;
        int mx = 0;
        for(int right = 0; right < n; right++) {
            if(arr[right] == 0) {
                zero += 1;
            }
            while(zero > 1) {
                if(arr[left] == 0) {
                    zero -= 1;
                }
                left += 1;
            }
            mx = Math.max(mx, right-left+1);
        }
        System.out.println(mx);
    }
}
