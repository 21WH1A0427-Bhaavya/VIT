import java.util.Scanner;
public class GoodArray {
    public static int gcd(int a, int b) {
        if(b == 0) {
            return a;
        }
        return gcd(b, a%b);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0; i<n; i++) {
            arr[i] = sc.nextInt();
        }
        int curr = 0;
        for(int i: arr) {
            curr = gcd(curr, i);
        }
        System.out.println(curr);
    }
}