import java.util.*;
public class StackUsingQ {
    Queue<Long> q;
    StackUsingQ() {
        q = new LinkedList<>();
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();
        StackUsingQ q = new StackUsingQ();
        for(int i=0; i<n; i++) {
            String s = sc.nextLine().trim();
            String[] parts = s.split("\\s+");
            String cmd = parts[0];
            if("push".equals(cmd)) {
                q.push(Long.parseLong(parts[1]));
            }
            else if("pop".equals(cmd)) {
                long x = q.pop();
                System.out.println(x);
            }
            else if("top".equals(cmd)) {
                long x = q.peek();
                System.out.println(x);
            }
            else if("empty".equals(cmd)) {
                System.out.println(q.empty());
            }
        }
    }
    public void push(Long x) {
        q.add(x);
        int sz = q.size();
        for(int i=0; i<sz-1; i++) {
            q.add(q.remove());
        }
    }
    public long pop() {
        if(q.isEmpty()) return -1L;
        return q.remove();
    }
    public long peek() {
        if(q.isEmpty()) return -1L;
        return q.peek();
    }
    public boolean empty() {
        return q.isEmpty();
    }
}
