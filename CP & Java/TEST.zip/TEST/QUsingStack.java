import java.util.Scanner;
import java.util.Deque;
import java.util.ArrayDeque;
public class QUsingStack {
    Deque<Integer> stackPush;
    Deque<Integer> stackPop;
    QUsingStack() {
        stackPush = new ArrayDeque<>();
        stackPop = new ArrayDeque<>();
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();
        QUsingStack q = new QUsingStack();
        for(int i=0; i<n; i++) {
            String s = sc.nextLine().trim();
            String[] parts = s.split("\\s+");
            String cmd = parts[0];
            if("push".equals(cmd)) {
                q.push(Integer.parseInt(parts[1]));
            }
            else if("pop".equals(cmd)) {
                long x = q.pop();
                System.out.println(x);
            }
            else if("peek".equals(cmd)) {
                long x = q.peek();
                System.out.println(x);
            }
            else if("empty".equals(cmd)){
                System.out.println(q.empty());
            }
        }
    }
    public void push(int x) {
        stackPush.push(x);
    }
    public void transfer() {
        if(stackPop.isEmpty()) {
            while(!stackPush.isEmpty()) {
                stackPop.push(stackPush.pop());
            }
        }
    }
    public long pop() {
        transfer();
        if(stackPop.isEmpty()) {
            return -1L;
        }
        return stackPop.pop();
    }
    public long peek() {
        transfer();
        if(stackPop.isEmpty()) return -1L;
        return stackPop.peek();
    }
    public boolean empty() {
        return stackPush.isEmpty() && stackPop.isEmpty();
    }
}
