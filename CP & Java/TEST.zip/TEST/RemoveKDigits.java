import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Scanner;
public class RemoveKDigits {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String num = sc.next();
        int k = sc.nextInt();
        System.out.println(remove(num, k));
    }
    public static String remove(String num, int k) {
        Deque<Character> stack = new ArrayDeque<>();
        for(char ch : num.toCharArray()) {
            while(!stack.isEmpty() && k>0 && stack.peekLast() > ch) {
                stack.removeLast();
                k--;
            }
            stack.addLast(ch);
        }
        while(!stack.isEmpty() && k > 0) {
            stack.removeLast();
            k--;
        }
        StringBuilder sb = new StringBuilder();
        while(!stack.isEmpty()) {
            sb.append(stack.removeFirst());
        }
        while(sb.length() > 0 && sb.charAt(0) == '0') {
            sb.deleteCharAt(0);
        }
        return sb.length() == 0 ? "0" : sb.toString();
    }
}
