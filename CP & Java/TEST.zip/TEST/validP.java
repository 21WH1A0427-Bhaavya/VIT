import java.util.Scanner;
import java.util.Stack;
public class validP {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.next();
        System.out.println(isValid(str));
    }
    public static boolean isValid(String s) {
        Stack<Character> stack = new Stack<>();
        for(char c: s.toCharArray()) {
            if(c == '(' || c == '[' || c == '{') {
                stack.push(c);
            }
            else {
                if(stack.isEmpty()) {
                    return false;
                }
                else {
                    if(c == ')' && stack.peek() == '(') {
                        stack.pop();
                    }
                    else if(c == ']' && stack.peek() == '[') {
                        stack.pop();
                    }
                    else if(c == '}' && stack.peek() == '{') {
                        stack.pop();
                    }
                }
            }
        }
        return stack.isEmpty();
    }
}
