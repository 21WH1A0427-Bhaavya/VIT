import java.util.Scanner;
import java.util.Stack;
public class PostFix {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String[] str = new String[n];
        for(int i=0; i<n; i++) {
            str[i] = sc.next();
        }
        int res = rpn(str);
        System.out.println(res);
    }
    public static int rpn(String[] str) {
        Stack<Integer> stack = new Stack<>();
        int res = 0;
        for(String s : str) {
            if(!"+-*/".contains(s)) {
                stack.push(Integer.parseInt(s));
            }
            else {
                int b = stack.pop();
                int a = stack.pop();
                switch(s) {
                    case "+": res = a+b; break;
                    case "-": res = a-b; break;
                    case "*": res = a*b; break;
                    case "/": res = a/b; break;
                }
                stack.push(res);
            }
        }
        return res;
    }
}
