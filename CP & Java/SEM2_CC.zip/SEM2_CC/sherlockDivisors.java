import java.util.Scanner;
public class sherlockDivisors {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if(n%2 != 0) System.out.println(0);
        else {
            int m = n/2;
            int count = 1;
            for(int i=1; i<=Math.sqrt(m); i+= 1) {
                if(m%i == 0) {
                    count += 1;
                    if((m/i) != i) {
                        count += 1;
                    }
                }
            }
            System.out.println(count);
        }
    }
}
