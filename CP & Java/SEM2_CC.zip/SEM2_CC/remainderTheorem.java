import java.util.Scanner;
public class remainderTheorem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int k = sc.nextInt();
        int[] div = new int[k];
        int[] rem = new int[k];
        for(int i=0; i<k; i++) {
            div[i] = sc.nextInt();
        }
        for(int i=0; i<k; i++) {
            rem[i] = sc.nextInt();
        }

        int x = 1;
        int i = 0;
        while(true) {
            for(i=0; i<k; i++) {
                if(x % div[i] != rem[i]) {
                    break;
                }
            }
            if(i == k) {
                System.out.println(x);
                break;
            }
            x += 1;
        }
    }
}
