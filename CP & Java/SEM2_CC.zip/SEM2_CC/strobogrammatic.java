import java.util.Scanner;
import java.util.HashMap;
public class strobogrammatic {
    public static boolean isStrobogrammatic(String s) {
        HashMap<Character, Character> dict = new HashMap<>();
        dict.put('1', '1');
        dict.put('0', '0');
        dict.put('8', '8');
        dict.put('9', '6');
        dict.put('6', '9');
        
        int start = 0, end = s.length()-1;
        while(start <= end) {
            Character left = s.charAt(start);
            Character right = s.charAt(end);
            Character mapped = dict.get(left);
            if(mapped == null || mapped != right) {
                return false;
            }
            start += 1;
            end -= 1;
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        if(isStrobogrammatic(s)) {
            System.out.println("YES");
        }
        else {
            System.out.println("NO");
        }
    }
}
