import java.util.Scanner;
public class nthDigit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long n = sc.nextInt();
        long digitLen = 1;
        long count = 9;
        long start = 1;
        while(n > digitLen*count) {
            n = n - digitLen*count;
            digitLen += 1;
            count *= 10;
            start *= 10;
        }
        long num = start + ((n-1)/digitLen);
        String str = Long.toString(num);
        long idx = (n-1)/(int) digitLen;
        System.out.println(str.charAt((int) idx));
    }
}
