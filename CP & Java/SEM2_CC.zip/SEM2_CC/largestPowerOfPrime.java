import java.util.Scanner;
public class largestPowerOfPrime {
    public static boolean isPrime(int p) {
        if(p <= 1) return false;
        if(p == 2) return true;
        if(p%2 == 0) return false;
        for(int i=3; i<=Math.sqrt(p); i+=2) {
            if(p%i != 0) return false;
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int p = sc.nextInt();
        if(isPrime(p)) {
            int exp = 0;
            int divisor = p;
            while(divisor <= n) {
                exp += n/divisor;
                if(divisor > Long.MAX_VALUE/p) break;
                divisor = divisor*p;
            }
            System.out.println(exp);
        }
        else {
            System.out.println(0);
        }    
    }
}
