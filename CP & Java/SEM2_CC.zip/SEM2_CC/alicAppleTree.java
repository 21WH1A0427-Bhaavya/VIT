import java.util.Scanner;
public class alicAppleTree {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        int k = sc.nextInt();
        int s = sc.nextInt();
        int n = sc.nextInt();
        int e = sc.nextInt();
        int w = sc.nextInt();

        if(m <= s*k) System.out.println(m);
        else if(m <= s*k + e + w) System.out.println(m);
        else System.out.println(-1);
    }
}
