import java.util.Scanner;
import java.util.Stack;
public class ValidP {
    static Stack<Character> stack;
    ValidP() {
        stack = new Stack<>();
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        new ValidP();
        for(int i=0; i<str.length(); i++) {
            char ch = str.charAt(i);
            if(ch == '(' || ch == '{' || ch == '[') {
                stack.push(ch);
            }
            else {
                if(stack.isEmpty()) {
                    System.out.println("Invalid paranthesis");
                    return;
                }
                else {
                    if(ch == ')' && stack.peek() == '(') {
                        stack.pop();
                    }
                    else if(ch == ']' && stack.peek() == '[') {
                        stack.pop();
                    }
                    else if(ch == '}' && stack.peek() == '{') {
                        stack.pop();
                    }
                    // else {
                    //     System.out.println("Invalid paranthesis");
                    //     break;
                    // }
                }
            }
        }
        boolean res = (stack.isEmpty()) ? true : false;
        if(res) {
            System.out.println("Valid Parenthesis");
        }
        else {
            System.out.println("Invalid Parenthesis");
        }
    }
}
