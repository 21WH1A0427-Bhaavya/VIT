import java.util.Scanner;
public class ValidStringP {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        int low = 0, high = 0;
        for(char c: s.toCharArray()) {
            if(c == '(') {
                low++;
                high++;
            }
            else if(c == ')') {
                low--;
                high--;
            }
            else {
                low--;
                high++;
            }
            if(high < 0) {
                System.out.println("InValid Parenthesis");
                return;
            }
            if(low < 0) low = 0;
        }
        if(low == 0) {
            System.out.println("Valid Parenthesis");
        }
        else {
            System.out.println("InValid Parenthesis");
        }
    }
}
