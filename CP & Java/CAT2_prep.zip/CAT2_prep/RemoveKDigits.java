import java.util.Scanner;
import java.util.Stack;
import java.util.Deque;
import java.util.ArrayDeque;
public class RemoveKDigits {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String num = sc.next();
        int n = sc.nextInt();
        System.out.println(removeK(num, n));
    }
    public static String removeK(String num, int k) {
        Deque<Character> stack = new ArrayDeque<>();
        for(char c: num.toCharArray()) {
            while(!stack.isEmpty() && k > 0 && stack.peekLast() > c) {
                stack.removeLast();
                k--;
            }
            stack.addLast(c);
        }
        while(!stack.isEmpty() && k>0) {
            stack.removeLast();
            k--;
        }
        StringBuilder sb = new StringBuilder();
        while(!stack.isEmpty()) {
            sb.append(stack.removeFirst());
        }
        while(sb.length() > 0 && sb.charAt(0) == '0') {
            sb.deleteCharAt(0);
        }
        return sb.length() == 0 ? "0" : sb.toString();
    }
}
