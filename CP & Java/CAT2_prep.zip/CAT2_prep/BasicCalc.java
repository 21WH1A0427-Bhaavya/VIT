import java.util.Scanner;
import java.util.Stack;
public class BasicCalc {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String eq = sc.next();
        int res = calculation(eq);
        System.out.println(res);
    }
    public static int calculation(String s) {
        Stack<Integer> stack = new Stack<>();
        int number = 0;
        int sign = 1;
        int res = 0;
        for(int i=0; i<s.length(); i++) {
            char c = s.charAt(i);
            if(Character.isDigit(c)) {
                number = number*10 + (c - '0');
            }
            else if(c == '+') {
                res += sign*number;
                number = 0;
                sign = 1;
            }
            else if(c == '-') {
                res += sign*number;
                number = 0;
                sign = -1;
            }
            else if(c == '(') {
                stack.push(res);
                stack.push(sign);
                res = 0;
                sign = 1;
            }
            else if(c == ')') {
                res += sign*number;
                number = 0;
                res *= stack.pop();
                res += stack.pop();
            }
        }
        res += sign*number;
        return res;
    }
}
