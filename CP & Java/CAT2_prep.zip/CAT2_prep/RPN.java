import java.util.Scanner;
import java.util.Stack;
public class RPN {
    static Stack<Integer> stack;
    RPN() {
        stack = new Stack<>();
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        new RPN();
        int n = sc.nextInt();
        String[] str = new String[n]; 
        for(int i=0; i<n; i++) {
            str[i] = sc.next();
        }
        for(String s: str) {
            if("+-*/".contains(s)) {
                int b = stack.pop();
                int a = stack.pop();
                int res = 0;
                switch(s) {
                    case "+": res = a+b; break;
                    case "-": res = a-b; break;
                    case "*": res = a*b; break;
                    case "/": res = a/b; break;
                }
                stack.push(res);
            }
            else {
                stack.push(Integer.parseInt(s));
            }
        }
        System.out.println(stack.pop());
    }
}
