import java.util.Scanner;
import java.util.Stack;
public class MinStack {
    static Stack<Integer> stack;
    static Stack<Integer> minStack;
    MinStack() {
        stack = new Stack<>();
        minStack = new Stack<>();
    }
    public static void push(int val) {
        stack.push(val);
        if(minStack.isEmpty() || minStack.peek() > val) {
            minStack.push(val);
        }
    }
    public static void pop() {
        if(!stack.isEmpty()) {
            int removed = stack.pop();
            if(removed == minStack.peek()) {
                minStack.pop();
            }
        }
    }
    public static void top() {
        if(!stack.isEmpty()) {
            System.out.println(stack.peek());
        }
        else {
            System.out.println("Stack is empty");
        }
    }
    public static void getMin() {
        if(!minStack.isEmpty()) {
            System.out.println(minStack.peek());
        }
        else {
            System.out.println("Stack is empty");
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();
        new MinStack(); 
        for(int i=0; i<n; i++) {
            String operation = sc.nextLine();
            if(operation.startsWith("push")) {
                String[] parts = operation.split(" ");
                int val = Integer.parseInt(parts[1]);
                push(val);
            }
            else if(operation.equals("pop")) {
                pop();
            }
            else if(operation.equals("top")) {
                top();
            }
            else if(operation.equals("getMin")) {
                getMin();
            }
        }
    }
}