import java.util.Scanner;
class Node {
    int data;
    Node next;

    Node(int val) {
        data = val;
        next = null;
    }
}
public class PartitionList {
    public static Node partition(Node head, int x) {
        Node curr = head;
        Node beforeHead = new Node(0);
        Node afterHead = new Node(0);
        Node before = beforeHead, after = afterHead;
        while(curr != null) {
            if(curr.data < x) {
                beforeHead.next = curr;
                beforeHead = beforeHead.next;
            }
            else {
                afterHead.next = curr;
                afterHead = afterHead.next;
            }
            curr = curr.next;
        }
        beforeHead.next = after.next;
        afterHead.next = null;
        return before.next;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Node head = null, tail = null;
        for(int i=0; i<n; i++) {
            Node newNode = new Node(sc.nextInt());
            if(head == null) {
                head = newNode;
                tail = newNode;
            }
            else {
                tail.next = newNode;
                tail = tail.next;
            }
        }
        int x = sc.nextInt();
        Node res = partition(head, x);
        while(res != null) {
            System.out.print(res.data + " ");
            res = res.next;
        }
    }
}