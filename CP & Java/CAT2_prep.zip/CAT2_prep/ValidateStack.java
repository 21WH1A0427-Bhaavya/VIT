import java.util.Scanner;
import java.util.Stack;
public class ValidateStack {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] pushed = new int[n];
        int[] popped = new int[n];
        for(int i=0; i<n; i++) {
            pushed[i] = sc.nextInt();
        }
        for(int i=0; i<n; i++) {
            popped[i] = sc.nextInt();
        }
        System.out.println(validate(pushed, popped));
    }
    public static boolean validate(int[] pushed, int[] popped) {
        Stack<Integer> stack = new Stack<>();
        int j=0;
        for(int i=0; i<pushed.length; i++) {
            stack.push(pushed[i]);
            while(!stack.isEmpty() && j<popped.length && popped[j] == stack.peek()) {
                stack.pop();
                j++;
            }
        }
        return j == popped.length;
    }
}
