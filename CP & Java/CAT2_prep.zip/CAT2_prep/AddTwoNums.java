import java.util.Scanner;
public class AddTwoNums {

    public static Node add(Node head1, Node head2) {
        Node dummy = new Node(0);
        Node curr = dummy;
        int carry = 0;
        int sum = 0;
        while(head1 != null || head2 != null) {
            int x = (head1 != null) ? head1.data : 0;
            int y = (head2 != null) ? head2.data : 0;
            sum = x + y + carry;
            carry = sum/10;
            curr.next = new Node(sum%10);
            curr = curr.next;

            if(head1 != null) {
                head1 = head1.next;
            }
            if(head2 != null) {
                head2 = head2.next;
            }
        }
        if(carry > 0) {
            curr.next = new Node(carry);
        }
        return dummy.next;
    }
    public static Node reverse(Node head) {
        Node prev = null;
        Node curr = head;
        Node nxt = null;
        while(curr != null) {
            nxt = curr.next;
            curr.next = prev;
            prev = curr;
            curr = nxt;
        }
        return prev;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Node head1 = null, tail1 = null;
        for(int i=0; i<n; i++) {
            Node newNode = new Node(sc.nextInt());
            if(head1 == null) {
                head1 = newNode;
                tail1 = newNode;
            }
            else {
                tail1.next = newNode;
                tail1 = tail1.next;
            }
        }
        Node head2 = null, tail2 = null;
        for(int i=0; i<n; i++) {
            Node newNode = new Node(sc.nextInt());
            if(head2 == null) {
                head2 = newNode;
                tail2 = newNode;
            }
            else {
                tail2.next = newNode;
                tail2 = tail2.next;
            }
        }
        Node head = add(head1, head2);
        Node res = reverse(head);
        while(res != null) {
            System.out.print(res.data + " ");
            res = res.next;
        }
    }
}
