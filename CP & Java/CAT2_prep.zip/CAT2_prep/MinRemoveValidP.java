import java.util.HashSet;
import java.util.Scanner;
import java.util.Stack;
public class MinRemoveValidP {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        System.out.println(minValid(s));
    }
    public static String minValid(String s) {
        Stack<Integer> stack = new Stack<>();
        StringBuilder str = new StringBuilder();
        HashSet<Integer> hs = new HashSet<>();
        for(int i=0; i<s.length(); i++) {
            char ch = s.charAt(i);
            if(ch == '(') {
                stack.push(i);
            }
            else if(ch == ')') {
                if(!stack.isEmpty()) {
                    stack.pop();
                }
                else {
                    hs.add(i);
                }
            }
        }
        while(!stack.isEmpty()) {
            hs.add(stack.pop());
        }

        for(int i=0; i<s.length(); i++) {
            if(!hs.contains(i)) {
                str.append(s.charAt(i));
            }
        }
        return str.toString();
    }
}