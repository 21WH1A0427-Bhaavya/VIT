import java.util.Scanner;
class Node {
    int data;
    Node next;
    Node (int d) {
        data = d;
        next = null; 
    }
}
public class deleteMidN {
    public static Node deleteMid(Node head) {
        Node fast = head;
        Node slow = head;
        Node prev = null;
        
        while(fast != null && fast.next != null) {
            fast = fast.next.next;
            prev = slow;
            slow = slow.next;
        }
        prev.next = prev.next.next;
        return head;
    }
    public static Node deleteNEnd(Node head, int n) {
        Node fast = head;
        Node slow = head;
        Node prev = null;
        for(int i=0; i<n; i++) {
            fast = fast.next;
        }
        while(fast != null) {
            fast = fast.next;
            prev = slow;
            slow = slow.next;
        }
        prev.next = prev.next.next;
        return head;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Node head = null;
        Node tail = null;
        for(int i=0; i<n; i++) {
            int value = sc.nextInt();
            Node newNode = new Node(value);
            if(head == null) {
                head = newNode;
                tail = newNode;
            }
            else {
                tail.next = newNode;
                tail = newNode;
            }
        }
        //Node curr = deleteMid(head);
        int k = sc.nextInt();
        Node curr = deleteNEnd(head, k);
        while(curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}