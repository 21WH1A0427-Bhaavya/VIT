import java.util.Scanner;
// class Node {
//     int data;
//     Node next;
//     Node (int d) {
//         data = d;
//         next = null;
//     }
// }
public class MergeSortedLists {
    public static Node merge(Node h1, Node h2) {
        Node temp = new Node(0);
        Node dummy = temp;
        while((h1 != null) && (h2 != null)) {
            if(h1.data < h2.data) {
                dummy.next = h1;
                h1 = h1.next;
            }
            else {
                dummy.next = h2;
                h2 = h2.next;
            }
            dummy = dummy.next;
        }
        if(h1 != null) dummy.next = h1;
        if(h2 != null) dummy.next = h2;

        return temp.next;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Node head1 = null, tail1 = null;
        Node head2 = null, tail2 = null;
        int n1 = sc.nextInt();
        int n2 = sc.nextInt();
        for(int i=0; i<n1; i++) {
            Node newNode = new Node(sc.nextInt());
            if(head1 == null) {
                head1 = newNode;
                tail1 = newNode;
            }
            else {
                tail1.next = newNode;
                tail1 = newNode;
            }
        }
        for(int i=0; i<n2; i++) {
            Node newNode = new Node(sc.nextInt());
            if(head2 == null) {
                head2 = newNode;
                tail2 = newNode;
            }
            else {
                tail2.next = newNode;
                tail2 = newNode;
            }
        }
        Node curr = merge(head1, head2);
        while(curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}