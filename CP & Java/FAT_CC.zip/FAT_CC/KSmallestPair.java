import java.util.Scanner;
import java.util.PriorityQueue;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class KSmallestPair {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1 = sc.nextInt();
        int[] nums1 = new int[n1];
        for(int i=0; i<n1; i++) {
            nums1[i] = sc.nextInt();
        }
        int n2 = sc.nextInt();
        int[] nums2 = new int[n2];
        for(int i=0; i<n2; i++) {
            nums2[i] = sc.nextInt();
        }
        int k = sc.nextInt();
        List<List<Integer>> res = new ArrayList<>();
        PriorityQueue<int[]> minHeap = new PriorityQueue<>((a,b) -> (a[0] + a[1]) - (b[0]+b[1]));
        for(int i=0; i<Math.min(k, nums1.length); i++) {
            minHeap.offer(new int[] {nums1[i], nums2[0], 0});
        }
        while(k-- > 0 && !minHeap.isEmpty()) {
            int[] curr = minHeap.poll();
            res.add(Arrays.asList(curr[0], curr[1]));
            if(curr[2]+1 < nums2.length) {
                minHeap.offer(new int[] {curr[0], nums2[curr[2]+1], curr[2]+1});
            }
        }
        for(List<Integer> pair : res) {
            System.out.println(pair);
        }
    }
}