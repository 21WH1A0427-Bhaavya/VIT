import java.util.Scanner;
public class oddEvenList {
    public static Node oddeven(Node head) {
        Node oddH = new Node(0);
        Node evenH = new Node(0);
        Node curr1 = oddH;
        Node curr2 = evenH;
        while(head != null) {
            if(head.data % 2 == 1) {
                curr1.next = head;
                curr1 = curr1.next;
            }
            else {
                curr2.next = head;
                curr2 = curr2.next;
            }
            head = head.next;
        }
        curr2.next = null;
        curr1.next = evenH.next;
        return oddH.next;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Node head = null;
        Node tail = null;
        for(int i=0; i<n; i++) {
            Node newNode = new Node(sc.nextInt());
            if(head == null) {
                head = newNode;
                tail = newNode;
            }
            else {
                tail.next = newNode;
                tail = newNode;
            }
        }
        Node curr = oddeven(head);
        while(curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}