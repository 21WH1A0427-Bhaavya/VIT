import java.util.Scanner;
public class checkValidPString {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        int low = 0, high = 0;
        boolean flag = true;
        for(char c: s.toCharArray()) {
            if(c == '(') {
                low += 1;
                high += 1; 
            }
            else if(c == ')') {
                low -= 1;
                high -= 1;
            }
            else {
                low -= 1;
                high += 1;
            }
            if(high < 0) flag = false;
            if(low < 0) low = 0;
        }
        if(!flag || low != 0) {
            System.out.println("Invalid P");
        }
        else {
            System.out.println("Valid P");
        }
    }
}