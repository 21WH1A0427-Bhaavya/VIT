import java.util.Scanner;
public class addNumLL {
    
    public static Node add(Node h1, Node h2) {
        Node curr = new Node(0);
        Node dummy = curr;
        int sum = 0, carry = 0;
        while(h1 != null && h2 != null) {
            sum = h1.data + h2.data + carry;
            carry = sum/10;
            dummy.next = new Node(sum%10);
            h1 = h1.next;
            h2 = h2.next;
            dummy = dummy.next;
        }
        if(carry != 0) {
            dummy.next = new Node(carry);
        }
        return curr.next;
        
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1 = sc.nextInt();
        Node head1 = null, head2 = null, tail1 = null, tail2 = null;
        for(int i=0; i<n1; i++) {
            int value = sc.nextInt();
            Node newNode = new Node(value);
            if(head1 == null) {
                head1 = newNode;
                tail1 = newNode;
            }
            else {
                tail1.next = newNode;
                tail1 = newNode;
            }
        }
        int n2 = sc.nextInt();
        for(int i=0; i<n2; i++) {
            int value = sc.nextInt();
            Node newNode = new Node(value);
            if(head2 == null) {
                head2 = newNode;
                tail2 = newNode;
            }
            else {
                tail2.next = newNode;
                tail2 = newNode;
            }
        }
        Node curr = add(head1, head2);
        while(curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
} 