import java.util.Scanner;
public class maxProductArray {
    public static int prefixSum(int n, int arr[]) {
        int prefix = 1;
        int suffix = 1;
        int max = 0;
        for(int i=0; i<n; i++) {
            if(prefix == 0) prefix = 1;
            if(suffix == 0) suffix = 1;
            prefix = prefix*arr[i];
            suffix = suffix*arr[n-i-1];
            if(max < prefix) max = prefix;
            if(max < suffix) max = suffix;
        }
        return max;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0; i<n; i++) {
            arr[i] = sc.nextInt();
        }
        System.out.println(prefixSum(n, arr));
    }
}