import java.util.Scanner;
// class Node {
//     int data;
//     Node next;
//     Node (int d) {
//         data = d;
//         next = null;
//     }
// }
public class rotateLL {
    public static Node rotate(Node head, int n, int k) {
        k = k%10;
        Node curr = head;
        int i=0;
        while(i<(n-k-1)) {
            curr = curr.next;
            i += 1;
        }
        Node temp = curr.next;
        curr.next = null;
        Node newHead = temp;
        while(temp.next != null) {
            temp = temp.next;
        }
        temp.next = head;
        return newHead;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Node head = null, tail = null;
        for(int i=0; i<n; i++) {
            int value = sc.nextInt();
            Node newNode = new Node(value);
            if(head == null) {
                head = newNode;
                tail = newNode;
            }
            else {
                tail.next = newNode;
                tail = newNode;
            }
        }
        int k = sc.nextInt();
        Node curr = rotate(head, n, k);
        while(curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}