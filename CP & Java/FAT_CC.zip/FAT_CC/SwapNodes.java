import java.util.Scanner;
public class SwapNodes {
    public static Node swap(Node head, int n, int k) {
        Node first = head;
        for(int i=1; i<k; i++) {
            first = first.next;
        }
        Node second = head;
        for(int i=1; i<n-k+1; i++) {
            second = second.next;
        }
        int temp = first.data;
        first.data = second.data;
        second.data = temp;
        return head;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Node head = null, tail = null;
        for(int i=0; i<n; i++) {
            int value = sc.nextInt();
            Node newNode = new Node(value);
            if(head == null) {
                head = newNode;
                tail = newNode;
            }
            else {
                tail.next = newNode;
                tail = newNode;
            }
        }
        int k = sc.nextInt();
        Node curr = swap(head, n, k);
        while(curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    } 
}