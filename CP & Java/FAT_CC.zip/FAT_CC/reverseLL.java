import java.util.Scanner;
class Node {
    int data;
    Node next;
    Node (int d) {
        data = d;
        this.next = null;
    }
}
public class reverseLL {
    public static Node reverse(Node head) {
        Node prev = null;
        Node temp = null;
        Node curr = head;
        while(curr != null) {
            temp = curr.next;
            curr.next = prev;
            prev = curr;
            curr = temp;
        }
        return prev;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Node head = null, tail = null;
        int n = sc.nextInt();
        int i=0;
        while(i<n) {
            int value = sc.nextInt();
            Node newNode = new Node(value);
            if(head == null) {
                head = newNode;
                tail = newNode;
            }
            else {
                tail.next = newNode;
                tail = newNode;
            }
            i += 1;
        }
        Node curr = reverse(head);
        while(curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}