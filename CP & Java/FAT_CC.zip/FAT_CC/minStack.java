import java.util.Scanner;
import java.util.Stack;
public class minStack {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] output = new int[n];
        Stack<Integer> stk = new Stack<>();
        for(int i=0; i<n; i++) {
            String s = sc.next();
            if(s.equals("MinStack")) {
                Stack<Integer> minStk = new Stack<>();
                
            }
        }
        
    }
}