import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;
public class maxSumSubseq {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[][] arr = new int[n][2];
        for(int i=0; i<n; i++) {
            arr[i][0] = sc.nextInt();
            arr[i][1] = i;
        }
        int k = sc.nextInt();
        // sort by value - descending
        Arrays.sort(arr, (a, b) -> b[0]-a[0]);
        // select to k
        int[][] topK = new int[k][2];
        for(int i=0; i<k; i++) {
            for(int j=0; j<2; j++) {
                topK[i][j] = arr[i][j];
            }
        }
        //sort by index - ascending
        Arrays.sort(topK, Comparator.comparingInt(a -> a[1]));
        for(int i=0; i<k; i++) {
            System.out.print(topK[i][0] + " ");
        }
    }
}