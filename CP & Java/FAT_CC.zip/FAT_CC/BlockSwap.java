import java.util.Scanner;
public class BlockSwap {
    public static void swap(int arr[], int k) {
        int[] temp = new int[k];
        int n = arr.length;
        for(int i=0; i<k; i++) {
            temp[i] = arr[i];
        }
        for(int i=0; i<n-k; i++) {
            arr[i] = arr[i+k];
        }
        for(int i=n-k; i<n; i++) {
            arr[i] = temp[i-n+k];
        }
        return;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0; i<n; i++) {
            arr[i] = sc.nextInt();
        }
        int k = sc.nextInt();
        swap(arr, k);
        for(int i=0; i<n; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}