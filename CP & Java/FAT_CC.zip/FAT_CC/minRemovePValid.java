import java.util.Scanner;
public class minRemovePValid {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        StringBuilder res = new StringBuilder();
        int balance = 0;
        for(char c: s.toCharArray()) {
            if(c == '(') {
                balance++;
                res.append(c);
            }
            else if(c == ')') {
                if(balance == 0) continue;
                balance--;
                res.append(c);
            }
            else {
                res.append(c);
            }
        }
        StringBuilder finalRes = new StringBuilder();
        for(int i= res.length()-1; i>=0; i--) {
            char ch = res.charAt(i);
            if(ch == '(' && balance > 0) {
                balance--;
                continue;
            }
            finalRes.append(ch);
        }
        System.out.println(finalRes.reverse().toString());
    }
}