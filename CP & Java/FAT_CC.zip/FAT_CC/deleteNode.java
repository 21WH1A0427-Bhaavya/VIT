import java.util.Scanner;
// class Node {
//     int data;
//     Node next;
//     Node(int d) {
//         data = d;
//         next = null;
//     }
// }
public class deleteNode {
    public static Node delete(Node head, int target) {
        Node dummy = new Node(0);
        dummy.next = head;
        Node curr = dummy;
        while(curr.next != null) {
            if(curr.next.data == target) {
                curr.next = curr.next.next;
            }
            else {
                curr = curr.next;
            }
        }
        return dummy.next;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Node head = null, tail = null;
        int n = sc.nextInt();
        for(int i=0; i<n; i++) {
            int value = sc.nextInt();
            Node newNode = new Node(value);
            if(head == null) {
                head = newNode;
                tail = newNode;
            }
            else {
                tail.next = newNode;
                tail = newNode;
            }
        }
        int target = sc.nextInt();
        head = delete(head, target);
        while(head != null) {
            System.out.print(head.data + " ");
            head = head.next;
        }
    }
} 