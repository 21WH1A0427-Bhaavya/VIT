import java.util.Scanner;
import java.util.Stack;
public class BasicCalc {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        int res = 0, num = 0, sign = 1;
        Stack<Integer> stk = new Stack<>();
        for(char c: s.toCharArray()) {
            if(Character.isDigit(c)) {
                num = num*10 + (c-'0');
            }
            else if(c == '+') {
                res += sign*num;
                sign = 1;
                num = 0;
            }
            else if(c == '-') {
                res += sign*num;
                sign = -1;
                num = 0;
            }
            else if(c == '(') {
                stk.push(res);
                stk.push(sign);
                res = 0;
                sign = 1;
            }
            else if(c == ')') {
                res += sign*num;
                num = 0;
                res *= stk.pop();
                res += stk.pop();
            }
        }
        res += sign*num;
        System.out.println(res);
    }
}