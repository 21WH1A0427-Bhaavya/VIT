import java.util.Scanner;
public class removeDup {
    public static Node dup(Node head) {
        Node prev = head;
        Node curr = head;
        boolean flag = false;
        curr = curr.next;
        while(prev != null && curr != null) {
            if(prev.data != curr.data) {
                if(flag) {
                    prev.next = curr;
                    flag = false;
                }
                else {
                    prev = prev.next;
                }
            }
            else {
                flag = true;
            }
            curr = curr.next;
        }
        if(flag) {
            prev.next = null;
        }
        return head;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Node head = null, tail = null;
        for(int i=0; i<n; i++) {
            int value = sc.nextInt();
            Node newNode = new Node(value);
            if(head == null) {
                head = newNode;
                tail = newNode;
            }
            else {
                tail.next = newNode;
                tail = newNode;
            }
        }
        Node curr = dup(head);
        while(curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}