import java.util.Scanner;
import java.util.Stack;
public class validP {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        boolean flag = true;
        Stack<Character> stk = new Stack<>();
        for(char c: s.toCharArray()) {
            if(c == '(' || c == '[' || c == '{') {
                stk.push(c);
            }
            else {
                if(stk.isEmpty()) {
                    flag = false;
                    break;
                }
                if(c == ')' && stk.peek() == '(') stk.pop();
                else if(c == ']' && stk.peek() == '[') stk.pop();
                else if(c == '}' && stk.peek() == '{') stk.pop();
            }
        }
        if(!stk.isEmpty() || flag == false) {
            System.out.println("Invalid Paranthesis");
        }
        else {
            System.out.println("Valid Paranthesis");
        }
    }
}