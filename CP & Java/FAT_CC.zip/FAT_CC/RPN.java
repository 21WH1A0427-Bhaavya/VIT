import java.util.Scanner;
import java.util.Stack;
public class RPN {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String[] st = new String[n];
        Stack<Integer> stk = new Stack<>();
        for(int i=0; i<n; i++) {
            st[i] = sc.next();
        }
        for(String s : st) {
            if("+-*/".contains(s)) {
                int b = stk.pop();
                int a = stk.pop();
                switch(s) {
                    case "+":
                        stk.push(a+b);
                        break;
                    case "-":
                        stk.push(a-b);
                        break;
                    case "*":
                        stk.push(a*b);
                        break;
                    case "/":
                        stk.push(a/b);
                        break;
                }
            }
            else {
                stk.push(Integer.parseInt(s));
            }
        }
        System.out.println(stk.pop());
    }
}