import java.util.Scanner;
class NodeDL {
    int data;
    NodeDL next;
    NodeDL prev;
    NodeDL (int d) {
        data = d;
        next = null;
        prev = null;
    }
}
public class palindromeList {
    public static boolean palindrome(NodeDL head, NodeDL tail) {
        NodeDL start = head;
        NodeDL end = tail;
        while(start != end && start != null && end != null) {
            if(start.data != end.data) {
                return false;
            }
            start = start.next;
            end = end.prev;
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        NodeDL head = null, tail = null;
    
        for(int i=0; i<n; i++) {
            int value = sc.nextInt();
            NodeDL newNode = new NodeDL(value);
            if(head == null) {
                head = newNode;
                tail = newNode;
                head.next = tail;
                tail.prev = head;
            }
            else {
                tail.next = newNode;
                newNode.prev = tail;
                tail = newNode;
            }
        }
        boolean res = palindrome(head, tail);
        if(res) {
            System.out.println("Is a palindrome");
        }
        else {
            System.out.println("Is not a palindrome");
        }
    }
}