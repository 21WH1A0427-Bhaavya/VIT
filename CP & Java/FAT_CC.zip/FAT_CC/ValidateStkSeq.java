import java.util.Scanner;
import java.util.Stack;
public class ValidateStkSeq {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1 = sc.nextInt();
        int[] pushed = new int[n1];
        for(int i=0; i<n1; i++) {
            pushed[i] = sc.nextInt();
        }
        int n2 = sc.nextInt();
        int[] popped = new int[n2];
        for(int i=0; i<n2; i++) {
            popped[i] = sc.nextInt();
        }
        Stack<Integer> stk = new Stack<>();
        int j=0;
        for(int i=0; i<n1; i++) {
            stk.push(pushed[i]);
            while(!stk.isEmpty() && j<popped.length && popped[j] == stk.peek()) {
                stk.pop();
                j++;
            }
        }
        System.out.println(j == popped.length);
    }
}