import java.util.Scanner;
import java.util.PriorityQueue;
public class MaxProdKInc {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int MOD = 1_000_000_007;
        long product = 1;
        int n = sc.nextInt();
        PriorityQueue<Long> minHeap = new PriorityQueue<>();
        for(int i=0; i<n; i++) {
            minHeap.offer((long) sc.nextInt());
        }
        int k = sc.nextInt();
        while(k>0) {
            long smallest = minHeap.poll();
            long nextSmallest = minHeap.peek();
            long diff = nextSmallest - smallest;
            if(diff == 0) {
                smallest += 1;
                k -= 1;
            }
            else {
                long use = Math.max(k, diff);
                smallest += use;
                k -= use;
            }
            minHeap.offer(smallest);
        }
        while(!minHeap.isEmpty()) {
            product = (product*minHeap.poll() % MOD);
        }
        System.out.println((int) product);
    }
}