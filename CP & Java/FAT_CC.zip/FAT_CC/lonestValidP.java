import java.util.Scanner;
import java.util.Stack;
public class lonestValidP {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        int max = 0;
        Stack<Integer> stk = new Stack<>();
        stk.push(-1);
        for(int i=0; i<s.length(); i++) {
            char c = s.charAt(i);
            if(c == '(') {
                stk.push(i);
            }
            else {
                stk.pop();
                if(stk.isEmpty()) stk.push(i);
                else max = Math.max(max, i-stk.peek());
            }
        }
        System.out.println(max);
    }
}