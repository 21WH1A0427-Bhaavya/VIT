import java.util.Scanner;
public class largestPowerOfPrime {
    public static long func(int n, int p) {
        long exp = 0;
        long divisor = p;
        while(divisor <= n) {
            exp += n/divisor;
            if(divisor > Long.MAX_VALUE/p) break;
            divisor *= p;
        }
        return exp;
    }
    public static boolean isPrime(int p) {
        if(p <= 1) return false;
        if(p == 2) return true;
        if(p%2 == 0) return false;
        for(int i=3; i<Math.sqrt(p); i+=2) {
            if(p%i == 0) {
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int p = sc.nextInt();
        if(!isPrime(p)) {
            System.out.println(0);
        }
        else {
            long res = func(n, p);
            System.out.println(res);
        }
    }
}
