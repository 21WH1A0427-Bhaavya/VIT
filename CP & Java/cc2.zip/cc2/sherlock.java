import java.util.Scanner;
public class sherlock {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = n/2;
        int count = 0;
        if(n % 2 != 0) {
            System.out.println(0);
            return;
        }
        else {
            for(int i=1; i<=Math.sqrt(m); i+=1) {
                if(m%i == 0) {
                    count += 1;
                    if(i == (m/i)) {
                        count += 1;
                    }
                }
            }
        }
        System.out.println(count);
    }
}
