import java.util.Scanner;
import java.util.HashMap;
public class strobogrammatic {
    public static boolean isS(String num) {
        HashMap<Character, Character> dict = new HashMap<>();
        dict.put('0', '0');
        dict.put('1', '1');
        dict.put('6', '9');
        dict.put('8', '8');
        dict.put('9', '6');

        int start = 0, end = num.length()-1;
        while(start <= end) {
            char left = num.charAt(start);
            char right = num.charAt(end);

            Character map = dict.get(left);
            if(map == null || map != right) {
                return false;
            }
            start += 1;
            end -= 1;
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String num = sc.next(); 
        if(isS(num)) {
            System.out.println("YES");
        }
        else {
            System.out.println("NO");
        }
    }
}