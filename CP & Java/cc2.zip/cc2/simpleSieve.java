import java.util.Scanner;
import java.util.Arrays;
public class simpleSieve {
    public static int gcd(int a, int b) {
        if(a == 0) {
            return b;
        }
        return gcd(b%a, a);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        // boolean[] bool = new boolean[n+1];
        // Arrays.fill(bool, true);
        // for(int i=2; i*i<=n; i++) {
        //     for(int j=i*i; j<=n; j+=i) {
        //         bool[j] = false;
        //     }
        // }
        // for(int i=2; i<=n; i++) {
        //     if(bool[i] == true) {
        //         System.out.print(i + " ");
        //     }
        // }
        int count = 1;
        for(int i=2; i<n; i++) {
            if(gcd(i, n) == 1) {
                count += 1;
            }
        }
        System.out.println(count);
    }
}