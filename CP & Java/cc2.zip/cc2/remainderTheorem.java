import java.util.Scanner;
public class remainderTheorem {
    public static int func(int num[], int rem[], int k) {
        int x = 1;
        int j;
        while(true) {
            for(j=0; j<k; j++) {
                if(x % num[j] != rem[j]) {
                    break;
                }
            }
            if(j == k) {
                return x;
            }
            x += 1;
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] div = new int[n];
        for(int i=0; i<n; i++) {
            div[i] = sc.nextInt();
        }
        int[] rem = new int[n];
        for(int i=0; i<n; i++) {
            rem[i] = sc.nextInt();
        }
        int res = func(div, rem, n);
        System.out.println(res);
    }
}
