import java.util.Scanner;
import java.util.Stack;
public class RPN {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String[] s = new String[n];
        for(int i=0; i<n; i++) {
            s[i] = sc.next();
        }
        Stack<Integer> stk = new Stack<>();
        for(String c : s) {
            if("+-*/".contains(c)) {
                int b = stk.pop();
                int a = stk.pop();
                switch(c) {
                    case "+": 
                        stk.push(a+b); 
                        break;
                    case "-": 
                        stk.push(a-b); 
                        break;
                    case "*": 
                        stk.push(a*b); 
                        break;
                    case "/": 
                        stk.push(a/b); 
                        break;
                }
            }
            else {
                stk.push(Integer.parseInt(c));
            }
        }
        System.out.print(stk.peek());
    }
}