import java.util.Scanner;
class Node {
    int value;
    Node next;
    Node (int d) {
        value = d;
        next = null; 
    }
}
public class RemoveNthNode {
    public static Node remove(Node head, int k) {
        Node fast = head;
        Node slow = head;
        for(int i=0; i<k; i++) {
            fast = fast.next;
        }
        Node temp = null;
        while(fast!= null) {
            fast = fast.next;
            temp = slow;
            slow = slow.next;
        }
        temp.next = temp.next.next;
        return head;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Node head = null, tail = null;
        for(int i=0; i<n; i++) {
            int value = sc.nextInt();
            Node newNode = new Node(value);
            if(head == null) {
                head = newNode;
                tail = newNode;
            }
            else {
                tail.next = newNode;
                tail = newNode;
            }
        }
        int k = sc.nextInt();
        Node curr = remove(head, k);
        while(curr != null) {
            System.out.print(curr.value + " ");
            curr = curr.next;
        }
    }
}