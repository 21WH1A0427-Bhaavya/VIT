import java.util.Scanner;
import java.util.PriorityQueue;
public class KLargestElements {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0; i<n; i++) {
            arr[i] = sc.nextInt();
        }
        int k = sc.nextInt();
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        for(int i=0; i<n; i++) {
            minHeap.offer(arr[i]);
            if(minHeap.size() > k) {
                minHeap.poll();
            }
        }
        System.out.println(minHeap.peek());
    }
} 